import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy.fft import fft, fftfreq
from scipy.signal import resample

input_file = 'C:/Users/asus/Documents/SignalProject/EyIran.wav'  

fs, data = wavfile.read(input_file)

print("="*50)
print("Original audio file info:")
print(f"Sample rate: {fs} Hz")
print(f"Duration: {len(data)/fs:.2f} seconds")

# Normalize to [-1, 1]
data = data / np.max(np.abs(data))

# Resample the signal

# Slower signal (0.75x)
slow_factor = 0.75
slow_samples = int(len(data) * slow_factor)
data_slow = resample(data, slow_samples)
fs_slow = fs * slow_factor

# Faster signal (1.5x)
fast_factor = 1.5
fast_samples = int(len(data) * fast_factor)
data_fast = resample(data, fast_samples)
fs_fast = fs * fast_factor

print(f"\nSlower signal: {fs_slow:.0f} Hz, {len(data_slow)} samples")
print(f"Faster signal: {fs_fast:.0f} Hz, {len(data_fast)} samples")

# Calculate spectrums 

def get_spectrum(signal, fs):
    N = len(signal)
    X = fft(signal)
    X_mag = np.abs(X[:N//2])
    freqs = fftfreq(N, 1/fs)[:N//2]
    return freqs, X_mag

# Get spectrums for all three signals
freqs_orig, spec_orig = get_spectrum(data, fs)
freqs_slow, spec_slow = get_spectrum(data_slow, fs_slow)
freqs_fast, spec_fast = get_spectrum(data_fast, fs_fast)

# Plot 1: Original signal spectrum

plt.figure(figsize=(15, 5))
plt.plot(freqs_orig, spec_orig, linewidth=0.5, color='blue')
plt.xlabel('Frequency (Hz)', fontsize=12)
plt.ylabel('Magnitude', fontsize=12)
plt.title(f'Original Signal Spectrum (fs = {fs} Hz)', fontsize=14)
plt.grid(True, alpha=0.3)
plt.xlim(0, fs//2)
plt.tight_layout()
plt.show()

# Plot 2: Slower signal spectrum

plt.figure(figsize=(15, 5))
plt.plot(freqs_slow, spec_slow, linewidth=0.5, color='green')
plt.xlabel('Frequency (Hz)', fontsize=12)
plt.ylabel('Magnitude', fontsize=12)
plt.title(f'Slower Signal Spectrum (fs = {fs_slow:.0f} Hz)', fontsize=14)
plt.grid(True, alpha=0.3)
plt.xlim(0, fs_slow//2)
plt.tight_layout()
plt.show()

# Plot 3: Faster signal spectrum

plt.figure(figsize=(15, 5))
plt.plot(freqs_fast, spec_fast, linewidth=0.5, color='red')
plt.xlabel('Frequency (Hz)', fontsize=12)
plt.ylabel('Magnitude', fontsize=12)
plt.title(f'Faster Signal Spectrum (fs = {fs_fast:.0f} Hz)', fontsize=14)
plt.grid(True, alpha=0.3)
plt.xlim(0, fs_fast//2)
plt.tight_layout()
plt.show()
