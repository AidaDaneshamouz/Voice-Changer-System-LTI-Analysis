import numpy as np
from scipy.io import wavfile

# 1. Load input signal

fs, x = wavfile.read("C:/Users/asus/Documents/SignalProject/EyIran.wav")

x = x.astype(np.float32)
x = x / np.max(np.abs(x))  # normalization

# 2. Echo parameters

D = 4000
alpha = 0.6

# 3. Implement echo system
# y[n] = x[n] + alpha x[n-D]

y = np.zeros(len(x) + D)
y[:len(x)] += x
y[D:D+len(x)] += alpha * x

y = y / np.max(np.abs(y))

# 4. Save output

wavfile.write("echo_output.wav", fs, y.astype(np.float32))

print("Echo applied successfully.")