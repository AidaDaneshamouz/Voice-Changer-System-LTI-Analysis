import numpy as np
import matplotlib.pyplot as plt

alpha = 0.6
D = 4000

# Zeros
k = np.arange(D)
radius = alpha**(1/D)
zeros = radius * np.exp(1j*(2*k+1)*np.pi/D)

# Poles
poles = np.zeros(D)

plt.figure(figsize=(6,6))
plt.scatter(np.real(zeros), np.imag(zeros), s=5, label="Zeros")
plt.scatter(np.real(poles), np.imag(poles), marker='x', color='r', label="Poles")

circle = np.exp(1j*np.linspace(0,2*np.pi,1000))
plt.plot(np.real(circle), np.imag(circle), 'k--')

plt.xlabel("Real")
plt.ylabel("Imag")
plt.title("Pole-Zero Plot")
plt.legend()
plt.axis("equal")
plt.grid(True)
plt.show()

w = np.linspace(0, np.pi, 2000)
alpha = 0.6
D = 4000

H = np.abs(1 + alpha*np.exp(-1j*w*D))

plt.plot(w/np.pi, H)
plt.xlabel("Normalized Frequency (×π rad/sample)")
plt.ylabel("|H(e^{jω})|")
plt.title("Frequency Response Magnitude")
plt.grid(True)
plt.show()