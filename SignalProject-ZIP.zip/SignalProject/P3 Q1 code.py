import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

fs, x = wavfile.read("C:/Users/asus/Documents/SignalProject/EyIran.wav")  

x = x.astype(np.float32)
x = x / np.max(np.abs(x))

print("Sampling rate:", fs)
print("Number of samples:", len(x))

# Modulation parameters

fc = 4000  # Carrier frequency (Hz)
t = np.arange(len(x)) / fs

# Amplitude Modulation
# y[n] = x[n] cos(2πfct)

y = x * np.cos(2 * np.pi * fc * t)

# Save output file
wavfile.write("robot_voice.wav", fs, y.astype(np.float32))
print("Modulated file saved as robot_voice.wav")

import numpy as np
import matplotlib.pyplot as plt

def plot_spectrum(signal, fs, title):
    N = len(signal)
    fft_vals = np.fft.fft(signal)
    fft_vals = np.fft.fftshift(fft_vals)   
    freqs = np.fft.fftshift(np.fft.fftfreq(N, 1/fs))
    magnitude = np.abs(fft_vals)

    plt.plot(freqs, magnitude)
    plt.title(title)
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Magnitude")
    plt.grid(True)
    plt.xlim(-8000, 8000)    
    plt.show()


plot_spectrum(x, fs, "Original Signal Spectrum")

plot_spectrum(y, fs, "Modulated Signal Spectrum")