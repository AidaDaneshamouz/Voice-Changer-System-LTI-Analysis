import numpy as np
import matplotlib.pyplot as plt

def plot_spectrum(signal, fs, title):
    N = len(signal)
    fft_vals = np.fft.fft(signal)
    fft_vals = np.fft.fftshift(fft_vals)   
    freqs = np.fft.fftshift(np.fft.fftfreq(N, 1/fs))
    magnitude = np.abs(fft_vals)

    plt.plot(freqs, magnitude)
    plt.title(title)
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Magnitude")
    plt.grid(True)
    plt.xlim(-8000, 8000)  
    plt.show()


plot_spectrum(x, fs, "Original Signal Spectrum")

plot_spectrum(y, fs, "Modulated Signal Spectrum")