import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy.fft import fft, fftfreq

input_file = 'C:/Users/asus/Documents/SignalProject/EyIran.wav' 

fs, data = wavfile.read(input_file)

print("="*50)
print("Audio file info:")
print(f"Sample rate: {fs} Hz")
print(f"Duration: {len(data)/fs:.2f} seconds")

# Normalize to [-1, 1]
data = data / np.max(np.abs(data))

# Calculate frequency spectrum

N = len(data)
X = fft(data)
X_magnitude = np.abs(X[:N//2])
frequencies = fftfreq(N, 1/fs)[:N//2]  # f = (k/N) * fs

# Part D: Plot magnitude spectrum vs frequency (Hz)

# Plot 1: Full range (0 to Nyquist frequency)
plt.figure(figsize=(15, 5))
plt.plot(frequencies, X_magnitude, linewidth=0.5, color='blue')
plt.xlabel('Frequency (Hz)', fontsize=12)
plt.ylabel('Magnitude', fontsize=12)
plt.title('Frequency Spectrum - Full Range (0 to {} Hz)'.format(fs//2), fontsize=14)
plt.grid(True, alpha=0.3)
plt.xlim(0, fs//2)  # 0 to 22050 Hz for fs=44100
plt.tight_layout()
plt.show()

# Part E: bandwidth

# Cumulative energy method
energy = X_magnitude**2
cumulative_energy = np.cumsum(energy)
total_energy = cumulative_energy[-1]

energy_90_idx = np.where(cumulative_energy >= 0.9 * total_energy)[0][0]
energy_95_idx = np.where(cumulative_energy >= 0.95 * total_energy)[0][0]

freq_90 = frequencies[energy_90_idx]
freq_95 = frequencies[energy_95_idx]

print("\n" + "="*50)
print("PART E: Bandwidth Estimation")
print("="*50)
print(f"90% of energy below: {freq_90:.0f} Hz")
print(f"95% of energy below: {freq_95:.0f} Hz")
print(f"\nConclusion: The main energy of speech signal")
print(f"is concentrated in the range of 0 to {freq_95:.0f} Hz")

# Plot cumulative energy
plt.figure(figsize=(15, 5))
cumulative_percent = (cumulative_energy / total_energy) * 100
plt.plot(frequencies, cumulative_percent, linewidth=2, color='green')
plt.axhline(y=90, color='blue', linestyle='--', alpha=0.7, label='90% energy')
plt.axhline(y=95, color='red', linestyle='--', alpha=0.7, label='95% energy')
plt.axvline(x=freq_90, color='blue', linestyle=':', alpha=0.7)
plt.axvline(x=freq_95, color='red', linestyle=':', alpha=0.7)
plt.xlabel('Frequency (Hz)')
plt.ylabel('Cumulative Energy (%)')
plt.title('Cumulative Energy vs Frequency')
plt.grid(True, alpha=0.3)
plt.xlim(0, 8000)
plt.ylim(0, 100)
plt.legend()
plt.show()