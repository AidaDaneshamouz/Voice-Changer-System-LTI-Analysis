import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

# Create a simple test signal

fs_original = 1000  
t = np.arange(0, 1, 1/fs_original)   

# Two frequencies: 100 Hz (safe) and 350 Hz (dangerous)
f1 = 100
f2 = 350
# Equal amplitudes
signal_original = 1.0 * np.sin(2*np.pi*f1*t) + 1.0 * np.sin(2*np.pi*f2*t)

# Downsampling settings

downsample_factor = 2
fs_new = fs_original // 2  # 500 Hz
nyquist_new = fs_new / 2   # 250 Hz

print("="*50)
print("ALIASING DEMONSTRATION")
print("="*50)

# Method 1: Downsampling WITHOUT filter (with aliasing)

signal_down_no_filter = signal_original[::downsample_factor]

# Method 2: Downsampling WITH filter (no aliasing)

cutoff = nyquist_new / (fs_original/2)  # 250/500 = 0.5
b, a = signal.butter(8, cutoff, btype='low')
signal_filtered = signal.filtfilt(b, a, signal_original)
signal_down_with_filter = signal_filtered[::downsample_factor]

# Calculate spectrums

def get_spectrum_raw(sig, fs):
    N = len(sig)
    fft_vals = np.fft.fft(sig)
    fft_mag = np.abs(fft_vals[:N//2])
    freqs = np.fft.fftfreq(N, 1/fs)[:N//2]
    return freqs, fft_mag

freqs_orig, mag_orig = get_spectrum_raw(signal_original, fs_original)
freqs_no_filter, mag_no_filter = get_spectrum_raw(signal_down_no_filter, fs_new)
freqs_with_filter, mag_with_filter = get_spectrum_raw(signal_down_with_filter, fs_new)

# Plot with proper spacing

fig, axes = plt.subplots(3, 1, figsize=(15, 12))

# Original signal spectrum  
axes[0].plot(freqs_orig, mag_orig, 'b-', linewidth=1.5)
axes[0].axvline(x=nyquist_new, color='r', linestyle='--', linewidth=2,
                label=f'New Nyquist ({nyquist_new} Hz)')
axes[0].set_ylabel('Magnitude', fontsize=11)
axes[0].set_title('1. Original Signal Spectrum', fontsize=12, pad=8)  
axes[0].set_xlim(0, 500)
axes[0].grid(True, alpha=0.3)
axes[0].legend(loc='upper right', fontsize=9)
axes[0].tick_params(axis='x', labelsize=10)
axes[0].tick_params(axis='y', labelsize=10)

# Downsampled WITHOUT filter 
axes[1].plot(freqs_no_filter, mag_no_filter, 'r-', linewidth=1.5)
axes[1].axvline(x=nyquist_new, color='r', linestyle='--', linewidth=2,
                label=f'New Nyquist ({nyquist_new} Hz)')
f_alias = abs(f2 - fs_new)
axes[1].axvline(x=f_alias, color='purple', linestyle=':', linewidth=2,
                label=f'Aliased from {f2} Hz → {f_alias} Hz')
axes[1].axvline(x=f1, color='blue', linestyle=':', alpha=0.7, label=f'Original {f1} Hz')
axes[1].set_ylabel('Magnitude', fontsize=11)
axes[1].set_title('2. Downsampled WITHOUT Filter - WITH Aliasing', fontsize=12, pad=8)
axes[1].set_xlim(0, 250)
axes[1].grid(True, alpha=0.3)
axes[1].legend(loc='upper right', fontsize=9)
axes[1].tick_params(axis='x', labelsize=10)
axes[1].tick_params(axis='y', labelsize=10)

# Downsampled WITH filter 
axes[2].plot(freqs_with_filter, mag_with_filter, 'g-', linewidth=1.5)
axes[2].axvline(x=nyquist_new, color='r', linestyle='--', linewidth=2,
                label=f'New Nyquist ({nyquist_new} Hz)')
axes[2].axvline(x=f1, color='blue', linestyle=':', alpha=0.7, label=f'Original {f1} Hz')
axes[2].set_xlabel('Frequency (Hz)', fontsize=11)
axes[2].set_ylabel('Magnitude', fontsize=11)
axes[2].set_title('3. Downsampled WITH Filter - NO Aliasing', fontsize=12, pad=8)
axes[2].set_xlim(0, 250)
axes[2].grid(True, alpha=0.3)
axes[2].legend(loc='upper right', fontsize=9)
axes[2].tick_params(axis='x', labelsize=10)
axes[2].tick_params(axis='y', labelsize=10)

plt.subplots_adjust(hspace=0.5) 

plt.show()