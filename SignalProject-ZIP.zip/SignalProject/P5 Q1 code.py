import numpy as np
from scipy.io import wavfile
import matplotlib.pyplot as plt

fs, x = wavfile.read("C:/Users/asus/Documents/SignalProject/EyIran.wav")

if len(x.shape) > 1:
    x = x[:,0]

x = x.astype(np.float32)
x = x / np.max(np.abs(x))

# 1. Amplitude Modulation

fc = 4000
t = np.arange(len(x)) / fs
y_mod = x * np.cos(2*np.pi*fc*t)

# 2. Echo System

D = 4000
alpha = 0.6

y_final = np.zeros(len(y_mod) + D)
y_final[:len(y_mod)] += y_mod
y_final[D:D+len(y_mod)] += alpha * y_mod

y_final = y_final / np.max(np.abs(y_final))

wavfile.write("final_output.wav", fs, y_final.astype(np.float32))

print("Final combined effect saved.")

def plot_spectrum(signal, fs, title):
    N = len(signal)
    fft_vals = np.fft.fftshift(np.fft.fft(signal))
    freqs = np.fft.fftshift(np.fft.fftfreq(N, 1/fs))
    magnitude = np.abs(fft_vals)

    plt.figure(figsize=(10,5))
    plt.plot(freqs, magnitude)
    plt.title(title)
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Magnitude")
    plt.xlim(-8000, 8000)
    plt.grid(True)
    plt.show()

plot_spectrum(y_final, fs, "Final Signal Spectrum (Modulation + Echo)")