import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

input_file = 'C:/Users/asus/Documents/SignalProject/EyIran.wav'
fs, data = wavfile.read(input_file)
print("="*50)
print("Audio file info:")
print(f"Sample rate: {fs} Hz")
print(f"Number of samples: {len(data)}")
print(f"Duration: {len(data)/fs:.2f} seconds")

# Normalize to [-1, 1]
data = data / np.max(np.abs(data))

# Plot time domain signal
time = np.arange(len(data)) / fs
plt.figure(figsize=(15, 6))
plt.plot(time, data, linewidth=0.5, color='blue')
plt.xlabel('Time (seconds)', fontsize=12)
plt.ylabel('Amplitude', fontsize=12)
plt.title('Speech Signal in Time Domain', fontsize=14)
plt.grid(True, alpha=0.3)
plt.xlim(0, len(data)/fs)
plt.ylim(-1.1, 1.1)
plt.tight_layout()
plt.show()
